# Digital Studio — Portfolio

Premium web portfolio with 3 demo shoe store projects.

## 📁 Structure

```
portfolio/
├── index.html           ← Main portfolio site
├── vercel.json          ← Vercel config
├── README.md
└── projects/
    ├── apex-kicks/      ← Streetwear dark store
    │   └── index.html
    ├── velour/          ← Luxury boutique
    │   └── index.html
    └── stride/          ← Sport performance store
        └── index.html
```

## 🚀 Deploy to Vercel (Free, takes 2 minutes)

### Option 1 — Drag & Drop (easiest)
1. Go to **vercel.com** and sign up (free)
2. Click **"Add New Project"** → **"Import"**
3. Drag the entire `portfolio` folder onto the page
4. Click **Deploy** — done! You get a live URL like `your-name.vercel.app`

### Option 2 — Via GitHub (recommended)
1. Create a free account on **github.com**
2. Create a new repository (e.g. `my-portfolio`)
3. Upload all files from this folder to the repo
4. Go to **vercel.com** → **"Add New Project"**
5. Connect your GitHub account → select your repo
6. Click **Deploy**

### Option 3 — Vercel CLI
```bash
npm install -g vercel
cd portfolio
vercel
```
Follow the prompts — it deploys automatically.

## 🌐 Demo Sites Included

| Site | Style | Path |
|------|-------|------|
| APEX KICKS | Dark / Streetwear | `/projects/apex-kicks/` |
| VELOUR | Luxury / Light | `/projects/velour/` |
| STRIDE | Sport / Bold | `/projects/stride/` |

## ✏️ Customization

Before deploying, update in `index.html`:
- Your Fiverr link (search `fiverr.com`)
- Your email (search `hello@studio.dev`)
- Your stats (50+, 3+, 100%)
- Footer name (Digital Studio)
